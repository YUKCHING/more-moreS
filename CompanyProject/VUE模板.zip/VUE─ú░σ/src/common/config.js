export default {
  url: process.env.NODE_ENV === 'production'
    ? '//' + window.location.host
    : '//192.168.91.113:8080'
}
