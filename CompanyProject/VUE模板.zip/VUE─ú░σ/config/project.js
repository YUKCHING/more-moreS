function getCodeEnv () {
  const args = process.argv
  var res
  for (var i = 0; i < args.length; i++) {
    if (args[i].indexOf('--PROJECT=') !== -1) {
      res = args[i].split('=')[1] || ''
      break
    }
  }
  return res || 'production'
}

const PROJECT = `${getCodeEnv()}`

/**
 * apply - 车位申请
 * audit - 车位审核
 * monthly - 月卡缴费
 */

const { AssetsPath } = (() => {
  const def = {
    AssetsPath: ''
  }

  switch (PROJECT) {
    case 'apply':
      def.AssetsPath = '/apply'
      break;
    case 'audit':
      def.AssetsPath = '/audit'
      break;
    case 'monthly':
      def.AssetsPath = '/monthly'
      break;
    case 'temporary':
      def.AssetsPath = '/temporary'
      break;
  
    default:
      break;
  }

  return def
})()

module.exports = {
  PROJECT, AssetsPath
}