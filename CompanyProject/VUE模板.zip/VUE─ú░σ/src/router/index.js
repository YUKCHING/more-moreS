import Vue from 'vue'
import Router from 'vue-router'
import store from '@/store'
Vue.use(Router)


const router = new Router({
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    /**
     * 车位申请
     */
    {
      path: '/home',
      name: 'home',
      component: resolve => require(['@/views/home/index'], resolve),
      meta: {
        title: '首页'
      }
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title
  }
  if (to.query.access_token) {
    store.dispatch('setToken', {
      token: to.query.access_token
    }).then(() => {
      next()
    })
  } else {
    next()
  }
})

router.afterEach((to, from) => {
  window.scrollTo(0, 0)
})

export default router
