<template>
  <div :id="chartId"></div>
</template>
<script>
let echarts = require('echarts/lib/echarts')
require('echarts/lib/chart/pie')
require('echarts/lib/component/legend')
require('echarts/lib/component/tooltip')
require('echarts/lib/component/title')
export default {
  props: {
    chartId: {
      require: true,
      type: String,
      default: ''
    },
    title: {
      require: true,
      type: String,
      default: ''
    },
    data: {
      require: true,
      type: Array,
      default: () => []
    },
    com: {
      require: true,
      type: String,
      default: ''
    }
  },
  watch: {
    data () {
      this.setChartOption()
    }
  },
  data () {
    return {
      myChart: {}
    }
  },
  computed: {
    getChartOption () {
      return {
        title: {
          x: '2%',
          y: '5%',
          textAlign: 'left'
        },
        tooltip: {
          trigger: 'item',
          formatter: '访客人数<br />{b}: {c} ' + this.com + ' ({d}%)'
        },
        legend: {
          orient: 'vertical',
          right: '5%',
          top: 'middle',
          selected: true,
          data: []
        },
        series: [
          {
            type: 'pie',
            radius: ['45%', '65%'],
            center: ['33%', '55%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: true,
                position: 'center',
                fontSize: '18',
                color: 'rgba(0,0,0,0.5)',
                labelLine: {
                  show: false
                }
              }
            },
            itemStyle: {
              color: function (params) {
                const colorList = ['#1890FF', '#FF8A65', '#8543E0', '#F04864', '#FACC14', '#2FC25B', '#13C2C2', '#66FFFF', '#00FF33', '#FF1493', '#CAFF70', '#9ACD32', '#98FB98', '#98F5FF', '#9400D3', '#8DEEEE', '#B3EE3A', '#B2DFEE', '#C71585']
                return colorList[params.dataIndex]
              }
            },
            data: []
          }
        ]
      }
    }
  },
  mounted () {
    this.drawLine()
    this.setChartOption()
  },
  methods: {
    drawLine () {
      this.myChart = echarts.init(document.getElementById(this.chartId))
      // 绘制图表
      this.myChart.setOption(this.getChartOption)
    },
    setChartOption () {
      var data = this.data
      var total = 0
      this.data.forEach(ele => {
        total = total + Number(ele.value)
      })
      var legendData = this.data.map(ele => ele.name)
      this.myChart.setOption({
        title: {
          text: this.title
        },
        legend: {
          formatter: (params) => {
            let item = this.data.filter(ele => ele.name === params)[0]
            let str = params + ' ' + item.value + this.com
            return str
          },
          data: legendData
        },
        series: [
          {
            label: {
              normal: {
                formatter: (params) => {
                  return '总人数:\n' + total + this.com
                }
              }
            },
            data: data
          }
        ]
      })
    }
  }
}
</script>
