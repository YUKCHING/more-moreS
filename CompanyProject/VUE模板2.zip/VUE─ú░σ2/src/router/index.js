import Vue from 'vue'
import Router from 'vue-router'
import store from '@/store'

Vue.use(Router)

const router = new Router({
  mode: process.env.NODE_ENV === 'production' ? 'history' : '',
  base: process.env.NODE_ENV === 'production' ? '/pop/' : '',
  routes: [
    {
      path: '/',
      name: 'redirect',
      redirect: '/home'
    },
    {
      path: '/home',
      name: 'home',
      component: resolve => require(['@/view/index'], resolve),
      meta: {
        title: '首页'
      }
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title
  }
  if (to.query.access_token) {
    store.dispatch('setToken', {
      token: to.query.token
    }).then(() => {
      next()
    })
  } else {
    next()
  }
})

export default router
