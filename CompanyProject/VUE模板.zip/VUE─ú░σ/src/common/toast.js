import Vue from 'vue'
import { Toast } from 'vant'

Vue.use(Toast)

Vue.prototype.tSuccess = tSuccess
Vue.prototype.tFail = tFail
Vue.prototype.tWarn = tWarn
Vue.prototype.toast = toast
Vue.prototype.tLoading = tLoading
Vue.prototype.tClear = tClear
Vue.prototype.dAlert = dAlert
Vue.prototype.dConfirm = dConfirm

export function tSuccess (str) {
  Toast.success(str)
}

export function tFail (str) {
  Toast.fail(str)
}

export function tWarn (str) {
  Toast({
    message: str,
    icon: 'fail'
  })
}

export function toast (str) {
  Toast({
    message: str
  })
}

export function tLoading (str) {
  Toast.loading({
    duration: 0,
    forbidClick: true,
    loadingType: 'spinner',
    message: str
  })
}

export function tClear (str) {
  Toast.clear()
}

export function dAlert (title, str) {
  return new Promise((resolve, reject) => {
    Dialog.alert({
      title: title,
      message: str
    }).then(() => {
    })
  })
}

export function dConfirm (title, str) {
  return new Promise((resolve, reject) => {
    Dialog.confirm({
      title: title,
      message: str
    }).then(() => {
      resolve(true)
    }).catch(() => {
      resolve(false)
    })
  })
}
