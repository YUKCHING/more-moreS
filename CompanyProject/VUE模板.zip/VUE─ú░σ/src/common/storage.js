export function getStorageByKey (key) {
  return localStorage.getItem(key)
}

export function setStorageByKey (key, value) {
  return localStorage.setItem(key, value)
}

export function removeStorageByKeys (keys) {
  if (keys.length !== 0) {
    keys.forEach(ele => {
      localStorage.removeItem(ele)
    })
  }
}
