import request from '@/utils/request'

function sendGetRequest (url, data) {
  let paramUrl = url
  if (typeof (data) === 'object') {
    let keys = Object.keys(data)
    if (keys.length > 0) {
      keys.forEach((ele, index) => {
        let tag = index === 0 ? '?' : '&'
        paramUrl = paramUrl + tag + ele + '=' + data[ele]
      })
    }
  }
  return request({
    url: paramUrl,
    method: 'get'
  })
}

function sendPostRequest (url, data) {
  return request({
    url: url,
    data: data,
    method: 'post'
  })
}

// 登记人数
export function peopleAdd (data) {
  let url = '/people/add'
  return sendPostRequest(url, data)
}

// 通过code获取用户信息
export function getByWxAuthorizeCode (data) {
  let url = '/people/getByWxAuthorizeCode'
  return sendGetRequest(url, data)
}
