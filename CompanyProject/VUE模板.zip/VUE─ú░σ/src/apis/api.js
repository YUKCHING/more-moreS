import request from '@/common/request'
import axios from 'axios'
import { tLoading, tClear } from '@/common/toast.js'

function sendPost (url, data) {
  return request({
    url: url,
    method: 'post',
    data: data
  })
}

function sendGet (url, data) {
  let paramUrl = url
  if (typeof (data) === 'object') {
    let keys = Object.keys(data)
    if (keys.length > 0) {
      keys.forEach((ele, index) => {
        let tag = index === 0 ? '?' : '&'
        paramUrl = paramUrl + tag + ele + '=' + data[ele]
      })
    }
  }
  return request({
    url: paramUrl,
    method: 'get'
  })
}

export function uploadImageRequest (url, data) {
  tLoading('图片上传中')
  return axios({
    url: url,
    method: 'post',
    data: data,
    dataType: 'text',
    headers: {
      'Content-Type': 'multipart/format-data'
    }
  }).then(res => {
    tClear()
    return res
  }).catch(() => {
    tClear()
  })
}

/**
 * 基础接口
 */
// 查询上传接口 /baseinfo/open/fileserver/getFileServerUrl
export function getFileServerUrl (data) {
  return sendGet('/baseinfo/open/fileserver/getFileServerUrl', data)
}

// 提交审核结果 /parking/mthcardapply/check
export function auditCarApply (data) {
  return sendPost('/parking/mthcardapply/check', data)
}
