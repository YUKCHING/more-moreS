<template>
  <div :id="chartId"></div>
</template>
<script>
let echarts = require('echarts/lib/echarts')
require('echarts/lib/chart/bar')
require('echarts/lib/component/legend')
require('echarts/lib/component/tooltip')
require('echarts/lib/component/title')
require('echarts/lib/component/dataZoom')
export default {
  props: {
    chartId: {
      require: true,
      type: String,
      default: ''
    },
    title: {
      require: true,
      type: String,
      default: ''
    },
    data: {
      require: true,
      type: Object,
      default: () => {}
    },
    com: {
      require: true,
      type: String,
      default: ''
    }
  },
  watch: {
    data () {
      this.setChartOption()
    }
  },
  data () {
    return {
      myChart: {}
    }
  },
  computed: {
    getChartOption () {
      return {
        color: ['#B5C3FF'],
        title: {
          x: '2%',
          y: '5%',
          textAlign: 'left'
        },
        legend: {
          top: '5%',
          right: '5%',
          orient: 'vertical',
          data: []
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            label: {
              background: '#6a7985'
            }
          },
          formatter: '{b0}: {c0} ' + this.com
        },
        grid: {
          left: '3%',
          right: '5%',
          bottom: '12%',
          containLabel: true
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            realtime: true,
            xAxisIndex: 0,
            start: 0,
            end: 100,
            bottom: '0%',
            left: '10%',
            right: '10%'

          },
          {
            type: 'inside',
            show: true,
            xAxisIndex: 0
          }
        ],
        xAxis: {
          type: 'category',
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          data: [],
          type: 'bar',
          barMaxWidth: 20,
          barGap: '200%'
        }]
      }
    }
  },
  mounted () {
    this.drawLine()
    this.setChartOption()
  },
  methods: {
    drawLine () {
      this.myChart = echarts.init(document.getElementById(this.chartId))
      // 绘制图表
      this.myChart.setOption(this.getChartOption)
    },
    setChartOption () {
      var legends = [this.data.name]
      var xAxis = this.data.xData
      var seriesData = [{
        name: this.data.name,
        type: 'bar',
        data: this.data.yData
      }]
      this.myChart.setOption({
        title: {
          text: this.title
        },
        legend: {
          data: legends
        },
        xAxis: [
          {
            data: xAxis
          }
        ],
        series: seriesData
      })
    }
  }
}
</script>
