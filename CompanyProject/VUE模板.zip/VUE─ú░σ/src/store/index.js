import Vue from 'vue'
import Vuex from 'vuex'
import appData from './appData'

Vue.use(Vuex)

/**
 * 获取 this.$store.getters.token
 * 设置 this.$store.dispatch('setToken', {
          token: '123123'
        })
 */

const store = new Vuex.Store({
  state: {},
  getters: {
    token: state => state.appData.token,
    packInfo: state => state.appData.parkInfo,
    temPayPlate: state => state.appData.temPayPlate,
    searchPlate: state => state.appData.searchPlate
  },
  mutitions: {},
  modules: {
    appData
  }
})

export default store
