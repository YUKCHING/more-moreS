'use strict'
// 正式环境发布为 true 测试环境发布为 false
const isProduction = true

// 正式环境appid
const proAppid = 'wx6a103a4aef1e104b'

// 正式环境Index跳转地址 http://yungu.yuanqu.cc/pop/register
const proIndexReurl = 'http%3a%2f%2fyungu.yuanqu.cc%2fpop%2fregister'

// 正式环境Info界面跳转地址 http://yungu.yuanqu.cc/pop/info?id=
const proInfoReurl = 'http%3a%2f%2fyungu.yuanqu.cc%2fpop%2finfo%3fid%3d'

// 调试环境appid
const testAppid = 'wx37a8d6970f848d42'

// 测试环境Index跳转地址 http://admin.no502zhang.com/pop/register
const testIndexReurl = 'http%3a%2f%2fadmin.no502zhang.com%2fpop%2fregister'

// 测试环境Info跳转地址 http://admin.no502zhang.com/pop/info?needToken=1&id=
const testInfoReurl = 'http%3a%2f%2fadmin.no502zhang.com%2fpop%2finfo%3fneedToken%3d1%26id%3d'

module.exports = {
  isProduction, proAppid, testAppid, proIndexReurl, proInfoReurl, testIndexReurl, testInfoReurl
}
