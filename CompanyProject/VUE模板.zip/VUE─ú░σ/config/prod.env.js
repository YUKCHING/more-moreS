'use strict'
let params = ''
if (process.argv.length > 2) {
  params = process.argv[2].slice(10)
}
let Redirect = ''
switch (params) {
  case 'apply':
    Redirect = '"/applycheck"'
    break;
  case 'audit':
    Redirect = '"/parkaudit"'
    break;
  case 'monthly':
    Redirect = '"/monthlypay"'
    break;
  case 'temporary':
    Redirect = '"/temparkselect"'
    break;

  default:
    break;
}

module.exports = {
  NODE_ENV: '"production"',
  REDIRECT: Redirect
}
