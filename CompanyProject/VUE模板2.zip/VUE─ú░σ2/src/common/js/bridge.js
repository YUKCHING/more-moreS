export default function Bridge () {
  this.browser = {
    versions: (function () {
      var u = navigator.userAgent
      return {// 移动终端浏览器版本信息
        trident: u.indexOf('Trident') > -1, // IE内核
        presto: u.indexOf('Presto') > -1, // opera内核
        webKit: u.indexOf('AppleWebKit') > -1, // 苹果、谷歌内核
        gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') === -1, // 火狐内核
        mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), // 是否为移动终端
        ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
        android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, // android终端或者uc浏览器
        iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, // 是否为iPhone或者QQHD浏览器
        iPad: u.indexOf('iPad') > -1, // 是否iPad
        webApp: u.indexOf('Safari') === -1 // 是否web应该程序，没有头部与底部
      }
    }()),
    language: (navigator.browserLanguage || navigator.language).toLowerCase()
  }

  this.initIosWebView = function (callback) {
    connectWebViewJavascriptBridge(function (bridge) {
      if (bridge !== undefined) {
        callback(bridge)
      } else {
        bridge.init(function (message, responseCallback) {
        })
        callback(bridge)
      }
    })
  }

  this.setHousingResources = function (roomId) {
    if (this.browser.versions.ios || this.browser.versions.iPhone || this.browser.versions.iPad) {
      // if (!window.WebViewJavascriptBridge) {
      //
      //   window.webkit.messageHandlers.setSmartHomeRoomId.postMessage({'roomId': roomId})
      //   return
      // }
      this.initIosWebView(function (bridge) {
        try {
          window.webkit.messageHandlers.setSmartHomeRoomId.postMessage({'roomId': roomId})
          bridge.callHandler('setSmartHomeRoomId', {'roomId': roomId}, function (response) {
          })
        } catch (e) {
        }
      })
    } else if (this.browser.versions.android) {
      try {
        window.smarti.setSmartHomeRoomId(roomId)
      } catch (e) {

      }
    }
  }

  this.startVoiceDictation = function () {
    if (this.browser.versions.ios || this.browser.versions.iPhone || this.browser.versions.iPad) {
      if (!window.WebViewJavascriptBridge) {
        window.webkit.messageHandlers.startVoiceDictation.postMessage({})
        return
      }
      this.initIosWebView(function (bridge) {
        try {
          console.log('startVoiceDictation')
          window.webkit.messageHandlers.startVoiceDictation.postMessage({})
          // bridge.callHandler('startVoiceDictation', {}, function (response) {
          //   console.log('start response ', response)
          // })
        } catch (e) {
        }
      })
    } else if (this.browser.versions.android) {
      try {
        window.smarti.startVoiceDictation()
      } catch (e) {

      }
    }
  }

  this.endVoiceDictation = function () {
    if (this.browser.versions.ios || this.browser.versions.iPhone || this.browser.versions.iPad) {
      if (!window.WebViewJavascriptBridge) {
        window.webkit.messageHandlers.endVoiceDictation.postMessage({})
        return
      }
      this.initIosWebView(function (bridge) {
        try {
          console.log('endVoiceDictation')
          window.webkit.messageHandlers.endVoiceDictation.postMessage({})
          // bridge.callHandler('endVoiceDictation', {}, function (response) {
          //   console.log('end response ', response)
          // })
        } catch (e) {
        }
      })
    } else if (this.browser.versions.android) {
      try {
        window.smarti.endVoiceDictation()
      } catch (e) {

      }
    }
  }

  this.OpenCaptureDevice = function (roomId) {
    if (this.browser.versions.ios || this.browser.versions.iPhone || this.browser.versions.iPad) {
      if (!window.WebViewJavascriptBridge) {
        window.webkit.messageHandlers.OpenCaptureDevice.postMessage({})
        return
      }
      this.initIosWebView(function (bridge) {
        try {
          bridge.callHandler('OpenCaptureDevice', {}, function (response) {
          })
        } catch (e) {
        }
      })
    }
  }
}

function connectWebViewJavascriptBridge (callback) {
  if (window.WebViewJavascriptBridge) {
    // eslint-disable-next-line
    callback(WebViewJavascriptBridge)
  } else {
    window.document.addEventListener('WebViewJavascriptBridgeReady', function () {
      // eslint-disable-next-line
      callback(WebViewJavascriptBridge)
    }, false)
  }
}
