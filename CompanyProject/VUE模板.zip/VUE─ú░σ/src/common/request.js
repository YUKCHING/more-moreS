import axios from 'axios'
import Qs from 'qs'
import store from '@/store'
import { tFail, tWarn } from './toast.js'
import config from './config'

export const request = axios.create({
  baseURL: config.url,
  headers: {
    // 'Content-Type': 'application/json;charset-UTF-8'
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
  }
})

// 请求拦截
request.interceptors.request.use(config => {
  // NProgress.start()

  let token = store.getters.token
  if (token) {
    config.headers.Authorization = token
  }

  if (config.method !== 'get') {
    if (config.data) {
      config.data = Qs.stringify(config.data)
    }
  }
  return config
}, err => {
  return Promise.reject(err)
})

// 响应拦截
request.interceptors.response.use(res => {
  // token失效
  if (res.data.data === 'loginout') {
    tWarn('token已失效，请重新打开')
  } else if (!res.data.result) {
    if (res.data.message) {
      tFail(res.data.message)
    }
  }
  return res.data
}, err => {
  switch (err.response.status) {
    case 500:
      tFail('服务器错误')
      break

    case 404:
      tFail('接口无法查找')
      break

    default:
      tFail('接口异常')
      break
  }
  console.log(err)
  return Promise.reject(err)
})

export default request
