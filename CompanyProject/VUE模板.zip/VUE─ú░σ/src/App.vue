<template>
  <div id="app">
    <!-- <mt-button class="global-back-button" @click="$router.go(-1)">返</mt-button> -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
html,
body {
  height: 100%;
  min-height: 100%;
  background-color: #f3f3f3;
  -webkit-text-size-adjust: 100%;
}
#app {
  height: 100%;
  font-family: 'PingFangSC-regular', 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  background: #f3f3f3;
  /* text-align: center; */
  color: #2c3e50;
}
.van-button {
  font-size: .65rem;
}
.global-back-button {
  z-index: 99;
  position: fixed;
  right: 1rem;
  top: 10rem;
  font-size: .5rem;
  height: 1.4rem;
  width: 1.4rem;
  text-align: center;
  border-radius: 7rem;
  border: 1px solid#87CEEB;
}
</style>
