<template>
  <div :id="chartId"></div>
</template>
<script>
let echarts = require('echarts/lib/echarts')
require('echarts/lib/chart/bar')
require('echarts/lib/component/legend')
require('echarts/lib/component/tooltip')
require('echarts/lib/component/title')
require('echarts/lib/component/dataZoom')
export default {
  props: {
    chartId: {
      require: true,
      type: String,
      default: ''
    },
    title: {
      require: true,
      type: String,
      default: ''
    },
    data: {
      require: true,
      type: Array,
      default: () => []
    }
  },
  watch: {
    data () {
      this.setChartOption()
    }
  },
  data () {
    return {
      myChart: {}
    }
  },
  computed: {
    getChartOption () {
      return {
        color: ['#B5F4FF', '#B5FFD4'],
        title: {
          x: '2%',
          y: '5%',
          textAlign: 'left'
        },
        legend: {
          top: '2%',
          right: '5%',
          orient: 'vertical',
          data: []
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            snap: false,
            label: {
              background: '#6a7985'
            }
          },
          formatter: '{b0}<br />入园人次: {c0}<br />员工人数: {c1}'
        },
        grid: {
          left: '3%',
          right: '5%',
          bottom: '12%',
          containLabel: true
        },
        dataZoom: [
          {
            type: 'slider',
            show: true,
            realtime: true,
            xAxisIndex: 0,
            start: 0,
            end: 100,
            bottom: '0%',
            left: '10%',
            right: '10%'

          },
          {
            type: 'inside',
            show: true,
            xAxisIndex: 0
          }
        ],
        xAxis: {
          type: 'category',
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: [],
            type: 'bar',
            barMaxWidth: 20,
            barGap: '0%',
            barCategoryGap: '50%'
          },
          {
            data: [],
            type: 'bar',
            barMaxWidth: 20
          }
        ]
      }
    }
  },
  mounted () {
    this.drawLine()
    this.setChartOption()
  },
  methods: {
    drawLine () {
      this.myChart = echarts.init(document.getElementById(this.chartId))
      // 绘制图表
      this.myChart.setOption(this.getChartOption)
    },
    setChartOption () {
      var legends = []
      var xAxis = []
      var seriesData = []
      if (this.data.length > 0) {
        xAxis = this.data[0].xData
        legends = this.data.map(ele => {
          return ele.name
        })
        seriesData = this.data.map(ele => {
          return {
            name: ele.name,
            type: 'bar',
            data: ele.yData
          }
        })
      }
      this.myChart.setOption({
        title: {
          text: this.title
        },
        legend: {
          data: legends
        },
        xAxis: [
          {
            data: xAxis
          }
        ],
        series: seriesData
      })
    }
  }
}
</script>
