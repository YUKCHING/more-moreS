<template>
  <div class="ver-card">
    <p class="p1" :style="{color: titleColor}">{{title}}</p>
    <p class="p2" :style="{color: numColor}">{{num}}</p>
    <p class="p3">{{com}}</p>
  </div>
</template>
<script>
export default {
  props: {
    title: {
      require: true,
      type: String,
      default: ''
    },
    num: {
      require: true,
      type: String,
      default: ''
    },
    com: {
      require: true,
      type: String,
      default: ''
    },
    titleColor: {
      require: false,
      type: String,
      default: '#000000'
    },
    numColor: {
      require: false,
      type: String,
      default: '#000000'
    }
  }
}
</script>
<style lang='scss' scoped>
.ver-card {
  display: inline-flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-family: 'PingFang SC';
  padding: 10px 0 9px;

  .p1 {
    font-size: 14px;
    line-height: 25px;
    font-weight: 600;
  }

  .p2 {
    font-size: 22px;
    line-height: 35px;
    font-weight: 600;
  }

  .p3 {
    font-size: 10px;
    line-height: 20px;
    color: #9A9A9A;
  }
}
</style>
