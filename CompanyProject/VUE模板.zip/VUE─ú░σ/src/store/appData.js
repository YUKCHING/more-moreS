import { getStorageByKey, setStorageByKey, removeStorageByKeys } from '@/common/storage.js'

const searchPlateKey = 'search_plate'
const temporaryPayPlateKey = 'tem_pay_plate'

const tokenKey = 'access_token'
const parkNameKey = 'parkName'
const parkIdKey = 'parkId'

const appData = {
  state: {
    token: process.env.NODE_ENV === 'production'
      ? getStorageByKey(tokenKey)
      : 'eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJqd3QiLCJpYXQiOjE1NjY4OTgwNjAsInN1YiI6IntcImRlcHRJZFwiOlwiXCIsXCJkZWZhdWx0VUNSZWxhdGlvbklkXCI6XCI4NzdiYzJmZjczMzc0MTMyOWZjZDg0YTNkZWEwYjVhOVwiLFwidXNlck5hbWVcIjpcIueuoeeQhuWRmFwiLFwiZ3JhbnRcIjpcIlBDXCIsXCJ1c2VySWRcIjpcImFkbWluXCIsXCJvcmdJZFwiOlwiMlwiLFwicGFya0lkXCI6XCI5ZjhjNzVmNjVkNDk0NWVkOTRhNjgxOWE3MjYwNzM1NFwifSIsImV4cCI6MTU2NjkwNTI2MH0.fJcnKwb1pFEzschoWgTFVJlyaQsDi4PBQnjjfTNl_3I',
    parkInfo: {
      name: getStorageByKey(parkNameKey),
      id: getStorageByKey(parkIdKey)
    },
    temPayPlate: getStorageByKey(temporaryPayPlateKey),
    searchPlate: getStorageByKey(searchPlateKey)
  },
  mutations: {
    SET_TOKEN (state) {
      state.token = getStorageByKey(tokenKey)
    },
    SET_PARKINFO (state) {
      state.parkInfo = {
        name: getStorageByKey(parkNameKey),
        id: getStorageByKey(parkIdKey)
      }
    },
    SET_TEM_PAY_PLATE (state) {
      state.temPayPlate = getStorageByKey(temporaryPayPlateKey)
    },
    SET_SEARCH_PLATE (state) {
      state.searchPlate = getStorageByKey(searchPlateKey)
    }
  },
  actions: {
    setToken ({ commit }, { token }) {
      setStorageByKey(tokenKey, token)
      commit('SET_TOKEN')
    },
    setParkInfo ({ commit }, { parkName, packId }) {
      setStorageByKey(parkNameKey, parkName)
      setStorageByKey(parkIdKey, packId)
      commit('SET_PARKINFO')
    },
    // 临时车缴费车牌记录
    setTemPayPlate ({ commit }, { plate }) {
      setStorageByKey(temporaryPayPlateKey, plate)
      commit('SET_TEM_PAY_PLATE')
    },
    removeTemPayPlate ({ commit }) {
      removeStorageByKeys([temporaryPayPlateKey])
      commit('SET_TEM_PAY_PLATE')
    },
    // 查询车牌的操作
    setSerchPlate ({ commit }, { plate }) {
      setStorageByKey(searchPlateKey, plate)
      commit('SET_SEARCH_PLATE')
    },
    removeSearchPlate ({ commit }) {
      removeStorageByKeys([searchPlateKey])
      commit('SET_SEARCH_PLATE')
    }
  }
}

export default appData
