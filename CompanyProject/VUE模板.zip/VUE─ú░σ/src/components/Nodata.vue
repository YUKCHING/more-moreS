<template>
  <div class="no-data">
    <img src="@/assets/image/nodata.svg" alt="">
    <span class="title-block">{{title}}</span>
  </div>
</template>
<script>
export default {
  props: {
    title: {
      require: true,
      type: String,
      default: '暂无数据'
    }
  }
}
</script>
<style lang='scss' scoped>
.no-data {
  height: 100%;
  display: flex;
  flex-direction: column;
  // justify-content: center;
  align-items: center;

  img {
    width: 200px;
    height: 200px;
    margin-top: 40%;
  }

  .title-block {
    font-size: .7rem;
    color: #848484;
  }
}
</style>
