import Vue from 'vue'
import { Button, Toast, Picker, Popup, Field, Icon, Checkbox, CheckboxGroup, Lazyload, ImagePreview, Tab, Tabs, List, Cell, CellGroup, Image, RadioGroup, Radio, Skeleton, Uploader, Dialog, DatetimePicker } from 'vant'

Vue.use(Button).use(Toast).use(Picker).use(Popup).use(Field).use(Icon).use(Checkbox).use(CheckboxGroup).use(Lazyload).use(ImagePreview).use(Tab).use(Tabs).use(List).use(Cell).use(CellGroup).use(Image).use(RadioGroup).use(Radio).use(Skeleton).use(Uploader).use(Dialog).use(DatetimePicker)
